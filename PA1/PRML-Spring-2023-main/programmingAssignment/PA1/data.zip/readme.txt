extract his zip file

place .ipynb file in the DATA folder

then run each code cell for checking purpose
